
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme/theme.dart';
import 'routing/router.dart';

class FoodiFitApp extends StatelessWidget {
  const FoodiFitApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = buildRouter();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: MaterialApp.router(
        title: 'FoodiFit',
        theme: buildFoodiFitTheme(),
        routerConfig: router,
        locale: const Locale('he'),
        supportedLocales: const [Locale('he'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
        ],
      ),
    );
  }
}
