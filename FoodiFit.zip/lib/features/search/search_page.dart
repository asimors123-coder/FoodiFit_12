
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../data/food_repository.dart';

class SearchPage extends StatefulWidget {
  final String initialQuery;
  const SearchPage({super.key, this.initialQuery = ''});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late TextEditingController _c;
  List<Map<String, Object?>> _results = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: widget.initialQuery);
    if (widget.initialQuery.isNotEmpty) {
      _search();
    }
  }

  Future<void> _search() async {
    setState(() => _loading = true);
    final rows = await FoodRepository.instance.searchFoods(_c.text);
    setState(() {
      _results = rows;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('חיפוש')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _c,
                  decoration: const InputDecoration(hintText: 'הקלד/י שם מאכל…'),
                  onSubmitted: (_) => _search(),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(onPressed: _search, child: const Text('חפש')),
            ]),
            const SizedBox(height: 16),
            if (_loading) const LinearProgressIndicator(),
            Expanded(
              child: ListView.separated(
                itemCount: _results.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (ctx, i) {
                  final r = _results[i];
                  return ListTile(
                    title: Text(r['name_he'] as String),
                    subtitle: Text('קלוריות ל-100ג׳: ${(r['kcal_per_100g'] as num).toString()}'),
                    onTap: () => context.push('/food/${r['id']}'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
