
import 'package:flutter/material.dart';
import '../../data/food_repository.dart';
import 'calc.dart';

class FoodDetailsPage extends StatefulWidget {
  final String id;
  const FoodDetailsPage({super.key, required this.id});

  @override
  State<FoodDetailsPage> createState() => _FoodDetailsPageState();
}

class _FoodDetailsPageState extends State<FoodDetailsPage> {
  Map<String, Object?>? _food;
  double _kcalPer100g = 0;
  double _grams = 100;
  String _unit = 'גרם';
  List<String> _unitOptions = ['גרם', 'כף', 'כפית', 'כוס', 'גביע', 'יחידה'];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final f = await FoodRepository.instance.getFoodById(widget.id);
    final servings = await FoodRepository.instance.unitsForFood(widget.id);
    final servUnitNames = servings.map((e) => e['unit_name'] as String).toSet();
    final opts = <String>{'גרם', ...servUnitNames, 'כף', 'כפית', 'כוס', 'גביע', 'יחידה'};

    setState(() {
      _food = f;
      _kcalPer100g = (f?['kcal_per_100g'] as num).toDouble();
      _unitOptions = opts.toList();
      _loading = false;
    });

    if (servUnitNames.isNotEmpty) {
      final u = servUnitNames.first;
      final grams = await FoodRepository.instance.gramsForFoodUnit(widget.id, u) ?? 100;
      setState(() { _unit = u; _grams = grams; });
    }
  }

  Future<void> _onUnitChanged(String? newUnit) async {
    if (newUnit == null) return;
    final grams = await FoodRepository.instance.gramsForFoodUnit(widget.id, newUnit) ?? _grams;
    setState(() { _unit = newUnit; _grams = grams; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final name = _food?['name_he'] as String? ?? '—';
    final kcal = calcCalories(kcalPer100g: _kcalPer100g, grams: _grams);

    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('קלוריות ל-100ג׳: ${_kcalPer100g.toStringAsFixed(0)}'),
            const SizedBox(height: 12),
            Row(children: [
              const Text('יחידה:'),
              const SizedBox(width: 12),
              DropdownButton<String>(
                value: _unit,
                items: _unitOptions.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                onChanged: _onUnitChanged,
              ),
              const SizedBox(width: 12),
              const Text('גרמים:'),
              const SizedBox(width: 8),
              SizedBox(
                width: 90,
                child: TextFormField(
                  initialValue: _grams.toStringAsFixed(0),
                  keyboardType: TextInputType.number,
                  onChanged: (v) {
                    final parsed = double.tryParse(v.replaceAll(',', '.'));
                    if (parsed != null) setState(() => _grams = parsed);
                  },
                ),
              ),
            ]),
            const SizedBox(height: 16),
            Text('סה"כ: ${kcal.toStringAsFixed(0)} קק"ל', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
      ),
    );
  }
}
