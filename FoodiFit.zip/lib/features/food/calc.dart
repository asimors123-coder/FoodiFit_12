
double calcCalories({required double kcalPer100g, required double grams}) {
  return (kcalPer100g / 100.0) * grams;
}
