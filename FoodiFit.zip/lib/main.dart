
import 'package:flutter/material.dart';
import 'app.dart';
import 'data/food_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FoodRepository.instance.init();
  runApp(const FoodiFitApp());
}
