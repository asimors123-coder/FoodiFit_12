
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class FoodRepository {
  FoodRepository._();
  static final FoodRepository instance = FoodRepository._();
  Database? _db;

  Future<void> init() async {
    if (_db != null) return;
    final docs = await getApplicationDocumentsDirectory();
    final dbPath = p.join(docs.path, 'foods.db');

    if (!await File(dbPath).exists()) {
      // copy prebuilt asset DB on first run
      final bytes = await rootBundle.load('assets/data/foods.db');
      await File(dbPath).writeAsBytes(bytes.buffer.asUint8List());
    }
    _db = await openDatabase(dbPath);
    await _db!.execute('PRAGMA foreign_keys = ON');
  }

  Future<List<Map<String, Object?>>> searchFoods(String query) async {
    final db = _ensureDb();
    if (query.trim().isEmpty) {
      return db.query('foods', orderBy: 'name_he', limit: 25);
    }
    final q = '%'+query.trim()+'%';
    return db.query('foods', where: 'name_he LIKE ?', whereArgs: [q], orderBy: 'name_he', limit: 50);
  }

  Future<Map<String, Object?>?> getFoodById(String id) async {
    final db = _ensureDb();
    final rows = await db.query('foods', where: 'id=?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, Object?>>> listUnits() async {
    final db = _ensureDb();
    return db.query('units', orderBy: 'name');
  }

  Future<List<Map<String, Object?>>> unitsForFood(String foodId) async {
    final db = _ensureDb();
    final rows = await db.query('servings', where: 'food_id=?', whereArgs: [foodId]);
    return rows;
  }

  Future<double?> gramsForFoodUnit(String foodId, String unitName) async {
    final db = _ensureDb();
    final rows = await db.query('servings', where: 'food_id=? AND unit_name=?', whereArgs: [foodId, unitName], limit: 1);
    if (rows.isNotEmpty) return (rows.first['grams'] as num).toDouble();
    final u = await db.query('units', where: 'name=?', whereArgs: [unitName], limit: 1);
    return u.isNotEmpty ? (u.first['grams'] as num).toDouble() : null;
  }

  Database _ensureDb() {
    final db = _db;
    if (db == null) {
      throw StateError('FoodRepository.init() must be called before use');
    }
    return db;
  }
}
